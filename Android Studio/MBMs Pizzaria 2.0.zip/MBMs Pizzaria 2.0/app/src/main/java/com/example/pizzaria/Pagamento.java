package com.example.pizzaria;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

public class Pagamento extends AppCompatActivity {
    Button btVoltar, btnVTFinal, btnPagamento;


    TextView txtVTFinal;
    MainActivity VTotal;
    RadioGroup rbgroup2;
    RadioButton rbnone, rbFive, rbTen, rbFifteen;
    Double Discount, VTFinal, VPago, VTroco;
    String Description;
    EditText edPago;
    Switch swEntrega;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento);
        btnVTFinal = findViewById(R.id.btnVTFinal);
        btVoltar = findViewById(R.id.btVoltar);
        txtVTFinal = findViewById(R.id.txtVTFinal);
        btnPagamento = findViewById(R.id.btnPagamento);
        rbgroup2 = findViewById(R.id.rbgroup2);
        rbnone = findViewById(R.id.rbnone);
        rbFive = findViewById(R.id.rbFive);
        rbTen = findViewById(R.id.rbTen);
        rbFifteen = findViewById(R.id.rbFifteen);
        edPago = findViewById(R.id.edPago);
        swEntrega = findViewById(R.id.swEntrega);


        btVoltar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                finish();
            }
        });

        btnVTFinal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int id = rbgroup2.getCheckedRadioButtonId();

                switch (id)
                {
                    case R.id.rbnone:
                    {
                        Discount = Double.valueOf(0);
                        Description = String.valueOf("Sem desconto");
                    }break;

                    case R.id.rbFive:
                    {
                        Discount = 0.05;
                        Description = String.valueOf("5%");
                    }break;

                    case R.id.rbTen:
                    {
                        Discount = 0.10;
                        Description = String.valueOf("10%");
                    }break;

                    case R.id.rbFifteen:
                    {
                        Discount = 0.15;
                        Description = String.valueOf("15%");
                    }break;
                }
                if (swEntrega.isChecked()) {
                    VTFinal = MainActivity.VTotal - (MainActivity.VTotal * Discount) + 10;

                    String msg = String.format("R$%5.2f", VTFinal);
                    txtVTFinal.setText(msg);
                }else{
                    VTFinal = MainActivity.VTotal - (MainActivity.VTotal * Discount);

                    String msg = String.format("R$%5.2f", VTFinal);
                    txtVTFinal.setText(msg);
                }
            }
        });

        btnPagamento.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                int id = rbgroup2.getCheckedRadioButtonId();

                switch (id)
                {
                    case R.id.rbnone:
                    {
                        Discount = Double.valueOf(0);
                        Description = String.valueOf("Sem desconto");
                    }break;

                    case R.id.rbFive:
                    {
                        Discount = 0.05;
                        Description = String.valueOf("5%");
                    }break;

                    case R.id.rbTen:
                    {
                        Discount = 0.10;
                        Description = String.valueOf("10%");
                    }break;

                    case R.id.rbFifteen:
                    {
                        Discount = 0.15;
                        Description = String.valueOf("15%");
                    }break;
                }

                if (swEntrega.isChecked()) {
                    VTFinal = MainActivity.VTotal - (MainActivity.VTotal * Discount) + 10;


                }else{
                    VTFinal = MainActivity.VTotal - (MainActivity.VTotal * Discount);


                }


                if (!edPago.getText().toString().isEmpty())
                {
                    VPago = Double.parseDouble(edPago.getText().toString());
                    VTroco = VPago - VTFinal;

                    if ( VPago < VTFinal )
                    {
                        String msg = String.format("Pagamento insuficiente!");
                        AlertDialog.Builder alerta = new AlertDialog.Builder(Pagamento.this);
                        alerta.setTitle("Aviso");
                        alerta.setMessage(msg);
                        alerta.setNeutralButton("OK", null);
                        alerta.show();
                    }
                    else
                    {
                        String resposta = String.format("Total a se pagar: %5.2f\n " +
                                "Desconto: %s\n " +
                                "Total pago: %5.2f\n Troco: %5.2" +
                                "" +
                                "" +
                                "f\n",VTFinal, Discount, VPago, VTroco);
                        AlertDialog.Builder alerta = new AlertDialog.Builder(Pagamento.this);
                        alerta.setTitle("Aviso");
                        alerta.setMessage(resposta);
                        alerta.setNeutralButton("OK",null);
                        alerta.show();
                    }
                }
                else
                {
                    VPago = Double.valueOf(0);

                    String msg = String.format("Pagamento insuficiente!!");
                    AlertDialog.Builder alerta = new AlertDialog.Builder(Pagamento.this);
                    alerta.setTitle("Aviso");
                    alerta.setMessage(msg);
                    alerta.setNeutralButton("OK", null);
                    alerta.show();
                }
            }
        });
    }
}