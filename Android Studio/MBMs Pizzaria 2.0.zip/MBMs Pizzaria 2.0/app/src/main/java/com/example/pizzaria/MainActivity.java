package com.example.pizzaria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.content.DialogInterface;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnpagar, btnlimpar, btnTotal;
    CheckBox ckcalabresa, ckmargarita, ckpalmito, ck4queijos, ckmodacasa;
    public static double total, VTotal, VTFinal;
    String txtpizza, saida;
    TextView  txtVTotal;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnlimpar = findViewById(R.id.btnlimpar);
        btnpagar = findViewById(R.id.btnpagar);
        btnTotal = findViewById(R.id.btnTotal);
        ckcalabresa = findViewById(R.id.ckcalabresa);
        ckmargarita = findViewById(R.id.ckmargarita);
        ckpalmito = findViewById(R.id.ckpalmito);
        ck4queijos = findViewById(R.id.ck4queijos);
        ckmodacasa = findViewById(R.id.ckmodacasa);
        txtVTotal = findViewById(R.id.txtVTotal);
        btnlimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ckcalabresa.setChecked(false);
                ckpalmito.setChecked(false);
                ckmodacasa.setChecked(false);
                ckmargarita.setChecked(false);
                ck4queijos.setChecked(false);

            }
        });
        btnpagar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                total = 0; txtpizza="";
                if (ckcalabresa.isChecked()) { total += 70; txtpizza+="Calabresa\n";}
                if (ckpalmito.isChecked()) {total += 70; txtpizza+="Palmito\n"; }
                if (ckmargarita.isChecked()) {total += 70; txtpizza +="Margarita\n"; }
                if (ck4queijos.isChecked()) {total += 85; txtpizza +="4 queijos\n"; }
                if (ckmodacasa.isChecked()) {total += 85; txtpizza +="Moda da casa\n"; }
                String msg = String.format("Total Pedido= $%5.2f", total);
                Toast.makeText(getBaseContext(), msg, Toast.LENGTH_LONG).show();
                Intent it = new Intent(getBaseContext(),Pagamento.class);
                Bundle params = new Bundle();
                params.putString("pizzas",txtpizza);  // repare que pizzas é o primeiro parametro
                params.putDouble("total",total);
                it.putExtras(params);
                startActivity(it);

            }
        });
        btnTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VTotal = 0;
                VTFinal = 0;
                if (ckcalabresa.isChecked()) {VTotal+= 70;}

                if (ckpalmito.isChecked()) {VTotal += 70; }
                if (ckmargarita.isChecked()) {VTotal += 70;  }
                if (ck4queijos.isChecked()) {VTotal += 85;  }
                if (ckmodacasa.isChecked()) {VTotal += 85;  }

                String msg = String.format("Valor: R$%5.2f",VTotal);
                txtVTotal.setText(msg);
                VTFinal = VTotal;

            }
        });


    }
}